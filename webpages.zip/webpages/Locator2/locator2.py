"""
locator.py
"""




class WebLocators:


   def __init__(self):
       self.name = "Name"
       self.Birth date = "Birth date"
       self.Birthday = "Birthday"
       self.Awards & recognition = "Awads & recognition"
       self.Page topics = "Page topics"
       self.Death date= "Death date"
       self.Gender identity = "Gender identity"
       self.Credits = "Credits"
       Adult names = "Adult names"
