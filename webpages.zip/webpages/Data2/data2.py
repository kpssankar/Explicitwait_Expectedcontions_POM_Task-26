"""
data.py
"""


class WebData:

    def __init__(self):
        self.url = "https://www.imdb.com/search/name/"
        self.name = "Sankar"
        self.Birthdate = "10-10-1990"
        self.Birthday = "10-10"
        self.Awardsrecognition = "Best Actress-Nominated"
        self.Pagetopics = "Award Nominations"
        self.Deathdate = "10-10-2090"
        self.Genderidentity = "Male"
        self.Credits = "100"
        self.Adultnames = "Include"
